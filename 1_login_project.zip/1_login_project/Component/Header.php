<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- css -->
    <link rel="stylesheet" type="text/css" href="../css/bootstrap-grid.css">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap-grid.min.css">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap-reboot.css">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap-reboot.min.css">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="/../css/bootstrap.min.css">
    
    <!-- style -->
    <style type="text/style" src="../js/bootstrap.bundle.js"></style>
    <style type="text/style" src="../js/bootstrap.bundle.min.js"></style>
    <style type="text/style" src="../js/bootstrap.js"></style>
    <style type="text/style" src="../js/bootstrap.min.js"></style>

</head>
<body>
