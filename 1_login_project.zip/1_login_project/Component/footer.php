
<div style="width:100%; height:100px"></div>
<div style="width:100%; height:60px" class="bg-light" >
<footer class="footer mt-auto py-3">
  <div class="container">
    <span class="text-dark"> This  is made by Ganesh </span>
  </div>
</footer>
</div>

</body>
</html>